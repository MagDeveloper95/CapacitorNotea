// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig : {
    apiKey: "AIzaSyCW6g6gJrs9vgsEfyqzs3zhRzJlMUv8ROQ",
  authDomain: "notea-a485a.firebaseapp.com",
  projectId: "notea-a485a",
  storageBucket: "notea-a485a.appspot.com",
  messagingSenderId: "712487321461",
  appId: "1:712487321461:web:9e252d80c88ca5f007dd3c",
  measurementId: "G-YMQGGS4N7Z",
    todoCollection:"todo"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
