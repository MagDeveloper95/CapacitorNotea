import { Component } from '@angular/core';
import { AlertController, LoadingController, ToastController } from '@ionic/angular';
import { toastController } from '@ionic/core';
import { Note } from '../shared/note.interface';
import { NoteService } from '../services/note.service';
import { ModalController } from '@ionic/angular';
//Cargamos la página modal
import { EditModalPage } from '../pages/edit-modal/edit-modal.page';
import { User } from '@codetrix-studio/capacitor-google-auth/dist/esm/user';


@Component({  
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {

  public notas: Note[] = [];
  public miLoading: HTMLIonLoadingElement;
  User: User;
  constructor(private ns: NoteService, public loadingController: LoadingController, public toastController: ToastController,
    private modalC:ModalController,public alertController: AlertController) { }

  async ngOnInit() {
    await this.cargaNotas();
  }

  public async cargaNotas(event?) {
    if (!event) {
      //mostrar loading
      await this.presentLoading();
    }
    this.notas = [];
    try {
      this.notas = await this.ns.getNotes().toPromise();
    } catch (error) {
      console.error(error);
      //notificar el error al usuario
      await this.presentToast("Error cargando datos", "danger");
    } finally {
      if (event) {
        event.target.complete();
      } else {
        //ocultar loading
        this.miLoading.dismiss();
      }
    }
  }

  async editar(nota:Note) {
    const modal = await this.modalC.create({
      component: EditModalPage,
      cssClass: 'my-custom-class',
      componentProps: {
        'note': nota,
      }
    });
    return await modal.present();
  }
   //////////////////////////////////////////////////
  //Hacer estos metodos en el servicio
  /**
   * Metodo que elimina una nota con un ion-alert y llama a la funcion eliminarNota si el usuario acepta
   * @param nota que se va a eliminar
   */
  public async borra(nota:Note){
    const alert = await this.alertController.create({
      cssClass: 'my-custom-class',
      header: 'Confirmación', 
      subHeader: 'Borrado de nota ' + nota.tittle,
      message: '¿Está seguro de borrar la nota?',
      buttons: [ {
        text: 'Cancelar',
        role: 'cancel',
        cssClass: 'secondary',
        handler: async () => {
          await this.miLoading.dismiss();
        }
      }, {
        text: 'Aceptar',
        handler: async () => {
          await this.ns.remove(nota.key);
          let i = this.notas.indexOf(nota,0);
          if(i>-1){
            this.notas.splice(i,1);
          }
          await this.miLoading.dismiss();
        }
      }]
    });
    await alert.present();
  }
  async presentLoading() {
    this.miLoading = await this.loadingController.create({
      message: '',
    });
    await this.miLoading.present();
  }

  async presentToast(msg: string, clr: string) {
    const miToast = await toastController.create({
      message: msg,
      duration: 2000,
      color: clr
    });
   miToast.present();
  }
  //searchbar para buscar notas
  public buscarNotas($event) {
    const texto = $event.target.value;
    if (texto.length > 0) {
      this.notas = this.notas.filter((note) => {
        return note.tittle.toLowerCase().indexOf(texto.toLowerCase()) > -1;
      });
    } else {
      this.cargaNotas();
    }
  }
  public async cargaInfinita(event) {}
  

}
