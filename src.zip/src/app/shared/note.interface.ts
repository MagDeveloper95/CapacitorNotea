export interface Note{
	key?:string,
	tittle:string,
	description:string,
}